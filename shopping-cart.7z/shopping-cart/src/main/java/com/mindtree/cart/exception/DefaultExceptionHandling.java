/**
 * 
 */
package com.mindtree.cart.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.mindtree.cart.service.ProductServiceImpl;

/**
* Default exception handling class to handle application exceptions.
* 
* @author Vishwanath
*/
@ControllerAdvice
public class DefaultExceptionHandling extends ResponseEntityExceptionHandler {
	/**
	 * Logger instance
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultExceptionHandling.class);
	/**
	 * Method to handle generic exception.
	 * @param ex, not null
	 * @return
	 */
	@ExceptionHandler(ShoppingCartException.class)
	@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public final ResponseEntity<ErrorMessage> somethingWentWrong(Exception ex) {
		ErrorMessage exResp = new ErrorMessage(ex.getMessage());
		LOGGER.error("Error while processing request: ", ex);
		return new ResponseEntity<ErrorMessage>(exResp, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

class ErrorMessage {
	private String message;
	
	public ErrorMessage(String message) {
		super();
		this.message = message;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ErrorMessage [message=" + message + "]";
	}
	
}