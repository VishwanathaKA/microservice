/**
 * 
 */
package com.mindtree.cart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cart.model.Product;

/**
* Product JPA Repository class to integrate with Database.
* 
* @author Vishwanath
*/
@Repository
public interface ProductsRepository extends JpaRepository<Product, Integer> {
	/**
	 * Find product by name.
	 * @param name, not null
	 * @return
	 */
	public Product findByName(String name);
	
	/**
	 * find product by category.
	 * @param category, not null
	 * @return
	 */
	public List<Product> findByCategory(Integer category);
}
