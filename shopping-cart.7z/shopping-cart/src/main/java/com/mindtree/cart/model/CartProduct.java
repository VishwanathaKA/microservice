/**
 * 
 */
package com.mindtree.cart.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
* Model class to hold Cart products.
* 
* @author Vishwanath
*/
@Entity
public class CartProduct {
	
	/**
	 * Auto generated cart product ID.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	/**
	 * One to one relationship with product.
	 */
	@OneToOne(cascade = CascadeType.ALL,
	        fetch = FetchType.LAZY)
	@JoinColumn(name = "productId", referencedColumnName = "productId")
	private Product product;
	
	/**
	 * Number of products user want to buy 
	 */
	@Column
	private Integer quantity;

	/**
	 * Foreign key reference to cart.
	 */
	@Column
	private Integer cartId;
	
	/**
	 * Cart Product default constructor
	 */
	public CartProduct() {}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the cart
	 */
	public Integer getCartId() {
		return cartId;
	}

	/**
	 * @param cart the cart to set
	 */
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartProduct other = (CartProduct) obj;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.getProduct()))
			return false;
		return true;
	}
	
	
}
