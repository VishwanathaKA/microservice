/**
 * 
 */
package com.mindtree.cart.common;

/**
 * @author M1017352
 *
 */
public enum ProductCategory {

	BOOK(2),
	APPAREL(1);
	
	public final Integer value;
	
	private ProductCategory(final Integer value) {
		this.value = value;
	}
}
