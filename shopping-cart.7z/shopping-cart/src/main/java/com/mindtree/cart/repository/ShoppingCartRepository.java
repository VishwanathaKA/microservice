/**
 * 
 */
package com.mindtree.cart.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cart.model.Cart;

/**
* Shopping cart JPA Repository class to integrate with Database.
* 
* @author Vishwanath
*/
@Repository
public interface ShoppingCartRepository extends JpaRepository<Cart, Integer> {

}
