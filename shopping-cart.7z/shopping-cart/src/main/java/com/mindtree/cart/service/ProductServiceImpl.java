/**
 * 
 */
package com.mindtree.cart.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.cart.common.ProductCategory;
import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Product;
import com.mindtree.cart.repository.ProductsRepository;

import net.bytebuddy.asm.Advice.This;

/**
* Implementation class for Product Service interface to fetch details for repository.
* 
* @author Vishwanath
*/
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly=true)
public class ProductServiceImpl implements ProductService {
	
	/**
	 * Logger instance
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductServiceImpl.class);
	/**
	 * inject Product repository bean.
	 */
	@Autowired
	private ProductsRepository productRepository;
	
	/**
	 * Find all the products available
	 * @return
	 */
	@Override
	public List<Product> findAll() {
		return productRepository.findAll();
	}
	
	/**
	 * Find product by product ID.
	 * @param productId, not null
	 * @return
	 */
	@Override
	public Optional<Product> findById(Integer productId) {
		 return productRepository.findById(productId);
	}

	/**
	 * Find product by product name.
	 * @param name, not null
	 * @return
	 */
	@Override
	public Product findByName(String name) {
		return productRepository.findByName(name);
	}
	
	/**
	 * Find products by category(Book, Apparel).
	 * @param category, not null
	 * @return
	 * @throws ShoppingCartException 
	 */
	@Override
	public List<Product> findByCategory(String category) throws ShoppingCartException {
		if(category == null || ProductCategory.valueOf(category) == null) {
			LOGGER.error("Category not supported :", category);
			throw new ShoppingCartException("Invalid Product category");
		}
		return productRepository.findByCategory(ProductCategory.valueOf(category).value);
	}

}
