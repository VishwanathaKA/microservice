/**
 * 
 */
package com.mindtree.cart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.PrimaryKeyJoinColumn;

/**
* Model class to hold books details, this class extends abstract product class.
* 
* @author Vishwanath
*/
@Entity
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "Product"))
public class Book extends Product {
	/**
	 * book's genre
	 */
	@Column
	private String genre;
	/**
	 * Author of book
	 */
	@Column
	private String authour;
	/**
	 * Book publisher
	 */
	@Column
	private String publiations;
	
	/**
	 * Default constructor 
	 */
	public Book() {}

	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * @return the authour
	 */
	public String getAuthour() {
		return authour;
	}

	/**
	 * @param authour the authour to set
	 */
	public void setAuthour(String authour) {
		this.authour = authour;
	}

	/**
	 * @return the publiations
	 */
	public String getPubliations() {
		return publiations;
	}

	/**
	 * @param publiations the publiations to set
	 */
	public void setPubliations(String publiations) {
		this.publiations = publiations;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((authour == null) ? 0 : authour.hashCode());
		result = prime * result + ((genre == null) ? 0 : genre.hashCode());
		result = prime * result + ((publiations == null) ? 0 : publiations.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		Book other = (Book) obj;
		if (authour == null) {
			if (other.authour != null)
				return false;
		} else if (!authour.equals(other.getAuthour()))
			return false;
		if (genre == null) {
			if (other.genre != null)
				return false;
		} else if (!genre.equals(other.getGenre()))
			return false;
		if (publiations == null) {
			if (other.publiations != null)
				return false;
		} else if (!publiations.equals(other.getPubliations()))
			return false;
		return true;
	}
	
}
