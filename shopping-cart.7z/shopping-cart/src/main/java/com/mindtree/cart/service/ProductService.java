/**
 * 
 */
package com.mindtree.cart.service;

import java.util.List;
import java.util.Optional;

import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Product;

/**
* Product Service interface to fetch details for repository.
* 
* @author Vishwanath
*/
public interface ProductService {
	/**
	 * Find all the products available
	 * @return
	 */
	List<Product> findAll();
	/**
	 * Find product by product ID.
	 * @param productId, not null
	 * @return
	 */
	Optional<Product> findById(Integer productId);
	/**
	 * Find product by product name.
	 * @param name, not null
	 * @return
	 */
	Product findByName(String name);
	/**
	 * Find products by category(Book, Apparel).
	 * @param category, not null
	 * @return
	 */
	List<Product> findByCategory(String category) throws ShoppingCartException;
}
