/**
 * 
 */
package com.mindtree.cart.service;

import java.util.Optional;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Cart;
import com.mindtree.cart.model.CartProduct;
import com.mindtree.cart.model.Product;
import com.mindtree.cart.repository.ProductsRepository;
import com.mindtree.cart.repository.ShoppingCartRepository;
import com.mindtree.cart.validator.ShoppingCartValidator;

/**
* Shopping cart implementation class to perform cart lifecycle actions.
* 
* @author Vishwanath
*/
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly=true)
public class ShoppingCartServiceImpl implements ShoppingCartService {

	/**
	 * Logger instance
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ShoppingCartServiceImpl.class);
	/**
	 * inject shopping cart repository bean.
	 */
	@Autowired
	private ShoppingCartRepository shoppingCartRepo;
	
	/**
	 * inject product repository bean.
	 */
	@Autowired
	private ProductService productService;

	/**
	 * Creates/initializes cart for user.
	 * @param cart, not null
	 * @return
	 */
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false)
	public Cart create(Cart cart) {
		Cart updatedCart = shoppingCartRepo.saveAndFlush(cart);
		return updatedCart;
	}
	
	/**
	 * Add product to shopping cart.
	 * @param cartId, not null
	 * @param cartProduct, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false)
	public Cart add(Integer cartId, CartProduct cartProduct) throws ShoppingCartException {
		ShoppingCartValidator.validateCartProduct(cartProduct);
		Cart cart = retrieve(cartId);
		Optional<Product> product = productService.findById(cartProduct.getProduct().getProductId());
		if(cart == null || product == null) {
			LOGGER.error("Invalid Cart or Product: Cart: {0} Product: {1}", cart, product);
			throw new ShoppingCartException("Cart or Product not available while adding product");
		}
		cartProduct.setProduct(product.get());
		
		// logic to check existing product
		if(cart.getCartProducts().contains(cartProduct)) {
			CartProduct matchedProd = findProductInCart(cartProduct, cart);
			matchedProd.setQuantity(matchedProd.getQuantity() + 1);
		}
		else {
			cartProduct.setQuantity(1);
			cart.getCartProducts().add(cartProduct);
		}
		cartProduct.setCartId(cart.getCartId());
		//calculate total price of all products in cart
		calculateTotalPrice(cart);
		Cart updatedCart = shoppingCartRepo.save(cart);
		return updatedCart;
	}


	/**
	 * Delete product from shopping cart
	 * @param cartId, not null
	 * @param product, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false)
	public Cart delete(Integer cartId, CartProduct cartProduct)  throws ShoppingCartException {
		Cart cart = retrieve(cartId);
		ShoppingCartValidator.validateCartProduct(cartProduct);
		if(cart == null) {
			LOGGER.error("Invalid Cart : {0}", cart);
			throw new ShoppingCartException("Cart not available to delete product");
		}
		removeFromCart(cartProduct, cart);
		
		//calculate total price of all products in cart
		calculateTotalPrice(cart);
		Cart updatedCart = shoppingCartRepo.save(cart);
		return updatedCart;
	}

	
	
	/**
	 * Modify product quantity in shopping cart.
	 * @param cartId, not null
	 * @param product, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false)
	public Cart modify(Integer cartId, CartProduct cartProduct) throws ShoppingCartException {
		Cart cart = retrieve(cartId);
		ShoppingCartValidator.validateCartProduct(cartProduct);
		if (cart == null || cartProduct.getQuantity()==null || cartProduct.getQuantity() < 0) {
			LOGGER.error("Invalid Cart: {0}, Quantity: {1}", cart, cartProduct.getQuantity());
			throw new ShoppingCartException("Cart not available or invalid quantity to modify product quantity");
		}
		if (cart.getCartProducts().contains(cartProduct)) {
			if (cartProduct.getQuantity() <= 0) {
				removeFromCart(cartProduct, cart);
			} else {
				CartProduct matchedProd = findProductInCart(cartProduct, cart);
				matchedProd.setQuantity(cartProduct.getQuantity());
			}
		} else {
			LOGGER.error("Product not available in cart {0}", cartProduct);
			throw new ShoppingCartException("Product not available in cart to modify");
		}
		// calculate total price of all products in cart
		calculateTotalPrice(cart);
		Cart updatedCart = shoppingCartRepo.save(cart);
		return updatedCart;
	}

	/**
	 * View shopping cart details.
	 * @param cartId, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@Override
	public Cart retrieve(Integer cartId) throws ShoppingCartException {
		Optional<Cart> cartOpt = shoppingCartRepo.findById(cartId);
		if(!cartOpt.isPresent()) {
			LOGGER.error("Cart not found with id: ", cartId);
			throw new ShoppingCartException("Cart not available, Initialize the cart");
		}
		Cart cart = cartOpt.get();
		calculateTotalPrice(cart);
		return cart;
	}


	/**
	 * Calculate total price of all products in cart.
	 * @param cart, not null
	 */
	private void calculateTotalPrice(Cart cart) {
		cart.setTotalPrice(0.0);
		if (cart != null) {
			cart.getCartProducts().stream().forEach(product -> cart
					.setTotalPrice(cart.getTotalPrice() + product.getProduct().getPrice() * product.getQuantity()));
		}
	}


	private CartProduct findProductInCart(CartProduct cartProduct, Cart cart) {
		Stream<CartProduct> matchingProd = cart.getCartProducts().stream().filter(cartProd -> 
		cartProd.equals(cartProduct));
		CartProduct matchedProd = matchingProd.findFirst().get();
		return matchedProd;
	}

	private void removeFromCart(CartProduct cartProduct, Cart cart) throws ShoppingCartException {
		if(cart.getCartProducts().contains(cartProduct)) {
			cart.getCartProducts().remove(cartProduct);
		}
		else {
			throw new ShoppingCartException("Product not available in cart to delete");
		}
	}

}
