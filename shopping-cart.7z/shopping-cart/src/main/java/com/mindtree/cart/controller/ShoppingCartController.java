/**
 * 
 */
package com.mindtree.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Cart;
import com.mindtree.cart.model.CartProduct;
import com.mindtree.cart.service.ShoppingCartService;

/**
* Controller class to handle shopping cart lifecycle operations.
* 
* @author Vishwanath
*/
@RestController
@RequestMapping(value="/shoppingcart/")
public class ShoppingCartController {
	
	/**
	 * Inject Shopping cart service bean
	 */
	@Autowired
	private ShoppingCartService shoppingCartService;
	
	/**
	 * Create/initialize shopping cart for user.
	 * @param cart , not null
	 * @return
	 */
	@RequestMapping(value="create", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public Cart create(@RequestBody final Cart cart) {
		return shoppingCartService.create(cart);
	}
	
	/**
	 * Add product to shopping cart.
	 * @param cartId , not null
	 * @param cartProduct , not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value="add/{cartId}", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Cart> add(@PathVariable Integer cartId, @RequestBody CartProduct cartProduct) throws ShoppingCartException {
		Cart cart = shoppingCartService.add(cartId, cartProduct);
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}
	
	/**
	 * Delete product from shopping cart.
	 * @param cartId, not null
	 * @param cartProduct, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value="delete/{cartId}", method=RequestMethod.DELETE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Cart delete(@PathVariable Integer cartId, @RequestBody CartProduct cartProduct) throws ShoppingCartException {
		Cart cart =  shoppingCartService.delete(cartId, cartProduct);
		return cart;
		
	}
	
	/**
	 * Modify quantity of products in shopping cart. 
	 * @param cartId, not null
	 * @param cartProduct, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value="modify/{cartId}", method=RequestMethod.PUT)
	public ResponseEntity<Cart> modify(@PathVariable Integer cartId, @RequestBody CartProduct cartProduct) throws ShoppingCartException {
		Cart cart = shoppingCartService.modify(cartId, cartProduct);
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}

	/**
	 * View shopping cart with all products present in cart.
	 * @param cartId, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	@RequestMapping(value="viewcart/{cartId}", method=RequestMethod.GET)
	public Cart viewCart(@PathVariable Integer cartId) throws ShoppingCartException {
		return shoppingCartService.retrieve(cartId);
	}
	
}
