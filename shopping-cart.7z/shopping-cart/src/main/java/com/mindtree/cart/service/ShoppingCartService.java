/**
 * 
 */
package com.mindtree.cart.service;

import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Cart;
import com.mindtree.cart.model.CartProduct;


/**
* Shopping cart Service interface to perform cart lifecycle actions.
* 
* @author Vishwanath
*/
public interface ShoppingCartService {

	/**
	 * Creates/initializes cart for user.
	 * @param cart, not null
	 * @return
	 */
	Cart create(Cart cart);
	/**
	 * Add product to shopping cart.
	 * @param cartId, not null
	 * @param cartProduct, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	Cart add(Integer cartId, CartProduct cartProduct) throws ShoppingCartException;
	/**
	 * Delete product from shopping cart
	 * @param cartId, not null
	 * @param product, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	Cart delete(Integer cartId, CartProduct product) throws ShoppingCartException;
	/**
	 * Modify product quantity in shopping cart.
	 * @param cartId, not null
	 * @param product, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	Cart modify(Integer cartId, CartProduct product) throws ShoppingCartException;
	/**
	 * View shopping cart details.
	 * @param cartId, not null
	 * @return
	 * @throws ShoppingCartException
	 */
	Cart retrieve(Integer cartId) throws ShoppingCartException;
}
