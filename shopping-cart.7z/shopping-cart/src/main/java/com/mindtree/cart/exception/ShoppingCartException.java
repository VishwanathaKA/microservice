/**
 * 
 */
package com.mindtree.cart.exception;

/**
* Application exception class.
* 
* @author Vishwanath
*/
public class ShoppingCartException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor
	 */
	public ShoppingCartException() {
	}

	/**
	 * @param message
	 */
	public ShoppingCartException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ShoppingCartException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ShoppingCartException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ShoppingCartException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
