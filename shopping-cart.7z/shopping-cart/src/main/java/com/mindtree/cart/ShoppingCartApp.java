package com.mindtree.cart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
* The class helps to initialize spring boot application.
* 
* @author Vishwanath
*/
@SpringBootApplication
@EnableJpaRepositories(basePackages="com.mindtree.cart.repository")
@EnableTransactionManagement
public class ShoppingCartApp 
{
	/**
	 * First method to be invoked to initialize web context.
	 * 
	 * @param args , may be null
	 */
    public static void main( String[] args )
    {
        SpringApplication.run(ShoppingCartApp.class, args);
    }
}
