/**
 * 
 */
package com.mindtree.cart.controller;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Product;
import com.mindtree.cart.service.ProductService;

/**
* Controller class to retrieve/find available products.
* 
* @author Vishwanath
*/
@RestController
@RequestMapping(value = "/shoppingcart/product/")
public class ProductController {

	/**
	 * Inject Product service.
	 */
	@Autowired
	private ProductService productService;

	/**
	 * Lists all available products in database.
	 * @return
	 */
	@RequestMapping(value="list", method=RequestMethod.GET)
	public Collection<Product> listAllProducts() {
		return productService.findAll();
	}
	
	/**
	 * Finds product by product ID in database.
	 * @param productId , not null
	 * @return
	 */
	@RequestMapping(value="/id/{productId}")
	public Optional<Product> findById(@PathVariable Integer productId) {
		return productService.findById(productId);
	}
	
	/**
	 * Finds product by product name.
	 * @param name , not null
	 * @return
	 */
	@RequestMapping(value="/name/{name}")
	public Product findByName(@PathVariable String name) {
		return productService.findByName(name);
	}
	
	/**
	 * Fetches all the products by category.
	 * @param category , not null
	 * @return
	 * @throws ShoppingCartException 
	 */
	@RequestMapping(value="/category/{category}")
	public List<Product> findByCategory(@PathVariable String category) throws ShoppingCartException {
		return productService.findByCategory(category);
	}
	
}
