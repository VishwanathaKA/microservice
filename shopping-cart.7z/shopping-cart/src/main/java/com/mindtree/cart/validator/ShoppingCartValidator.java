/**
 * 
 */
package com.mindtree.cart.validator;

import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.CartProduct;

/**
* Shopping cart validator class to validate request parameters.
* 
* @author Vishwanath
*/
public class ShoppingCartValidator {

	public static void validateCartProduct(CartProduct cartProduct) throws ShoppingCartException {
		if(cartProduct == null || cartProduct.getProduct() == null) {
			throw new ShoppingCartException("Madatory details are missing in request");
		}
	}
	
}
