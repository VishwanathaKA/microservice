/**
 * 
 */
package com.mindtree.cart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.PrimaryKeyJoinColumn;

/**
* Model class to hold apparel details, this class extends abstract product class.
* 
* @author Vishwanath
*/
@Entity
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "Product"))
public class Apparel extends Product {
	
	/**
	 * type of apparel
	 */
	@Column
	private String type;
	/**
	 * apparel brand
	 */
	@Column
	private String brand;
	/**
	 * apparel design
	 */
	@Column
	private String design;

	public Apparel() {}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the design
	 */
	public String getDesign() {
		return design;
	}

	/**
	 * @param design the design to set
	 */
	public void setDesign(String design) {
		this.design = design;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + ((design == null) ? 0 : design.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		/*Apparel other = (Apparel) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.getBrand()))
			return false;
		if (design == null) {
			if (other.design != null)
				return false;
		} else if (!design.equals(other.getDesign()))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.getType()))
			return false;*/
		return true;
	}


}
