package com.mindtree.cart.common;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.mindtree.cart.model.Apparel;
import com.mindtree.cart.model.Book;
import com.mindtree.cart.model.Product;

public class ProductsStub {

	public static Map<Long, Product> products = new HashMap<Long, Product>();
	
	static {
		Book book1 = new Book();
		book1.setProductId(1);
		book1.setName("Java");
		book1.setPrice(100);
		book1.setAuthour("Dennis");
		book1.setGenre("Tech");
		book1.setPubliations("Prakash");
		products.put(1L, book1);
		
		Book book2 = new Book();
		book2.setProductId(2);
		book2.setName("C++");
		book2.setPrice(200);
		book2.setAuthour("Dennis");
		book2.setGenre("Tech");
		book2.setPubliations("Prakash");
		products.put(2L, book2);
		
		Apparel apparel1 = new Apparel();
		apparel1.setProductId(3);
		apparel1.setName("Shirt");
		apparel1.setPrice(600);
		apparel1.setBrand("Philip");
		apparel1.setDesign("Round");
		apparel1.setType("Indian");
		products.put(3L, apparel1);
	}
	
	public static Collection<Product> listProducts() {
		return products.values();
	}
	
	public static Product getProduct(Long id) {
		return products.get(id);
	}
	
	public static List<Product> getByCategory(String category) {
		Stream<Product> filter = listProducts().stream().filter(prod -> prod instanceof Book);
		List<Product> books = filter.collect(Collectors.toList());
		return books;
	}
}
