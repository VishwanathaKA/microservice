package com.mindtree.cart.controller;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.cart.AbstractControlTest;
import com.mindtree.cart.model.Book;
import com.mindtree.cart.model.Cart;
import com.mindtree.cart.model.CartProduct;
import com.mindtree.cart.model.User;
import com.mindtree.cart.service.ShoppingCartService;

import junit.framework.Assert;

@Transactional
public class ShoppingCartControllerTest extends AbstractControlTest {

	@Mock
	private ShoppingCartService cartService;
	
	@InjectMocks
	private ShoppingCartController controller;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		setUp(controller);
	}
	
	@Test
	public void testAddProdut() throws Exception {
		
		String uri = "/shoppingcart/add/1";
		CartProduct cp = buildCartProduct(1, 1);
		/*Product product = buildBook(1, 100, "Data Structure");
		cp.setProduct(product);*/
		String mapToJson = super.mapToJson(cp);
		Cart cart = buildCart();
		Mockito.when(cartService.retrieve(1)).thenReturn(cart );
		cart.getCartProducts().add(cp);
		Mockito.when(cartService.add(1, cp)).thenReturn(cart);
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).content(mapToJson)).andReturn();
		String content = result.getResponse().getContentAsString();
		int status = result.getResponse().getStatus();
		Assert.assertEquals(status, 200);
		Assert.assertTrue(content.trim().length() > 0);
	}

	private Cart buildCart() {
		Cart cart = new Cart();
		cart.setCartId(1);
		User user = new User();
		user.setEmail("abc.gmail.com");
		user.setName("ABC");
		user.setPhoneNo(9989789);
		cart.setUser(user );
		Set<CartProduct> cartProducts = new HashSet<CartProduct>();
		cart.setCartProducts(cartProducts );
		return cart;
	}

	private CartProduct buildCartProduct(int id, int quantity) {
		CartProduct cp = new CartProduct();
		cp.setCartId(id);
		cp.setId(id);
		cp.setQuantity(quantity);
		return cp;
	}
	
	private Book buildBook(int prodId, int price, String name) {
		Book book = new Book();
		book.setProductId(prodId);
		book.setName(name);
		book.setPrice(price);
		book.setAuthour("Dennis");
		book.setGenre("Tech");
		book.setPubliations("Prakash");
		return book;
	}
}
