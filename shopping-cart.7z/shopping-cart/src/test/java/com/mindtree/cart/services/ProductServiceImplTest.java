/**
 * 
 */
package com.mindtree.cart.services;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.cart.AbstractTest;
import com.mindtree.cart.common.ProductCategory;
import com.mindtree.cart.common.ProductsStub;
import com.mindtree.cart.exception.ShoppingCartException;
import com.mindtree.cart.model.Product;
import com.mindtree.cart.repository.ProductsRepository;
import com.mindtree.cart.service.ProductService;
import com.mindtree.cart.service.ProductServiceImpl;

import junit.framework.Assert;

/**
 * @author M1017352
 *
 */
@Transactional
public class ProductServiceImplTest extends AbstractTest {

	@InjectMocks
	private ProductService productService = new ProductServiceImpl();

	@Mock
	private ProductsRepository productRepository;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testFindAll() {
		Mockito.when(productRepository.findAll()).thenReturn(new ArrayList(ProductsStub.listProducts()));
		List<Product> products = productService.findAll();
		Assert.assertEquals(3, products.size());
	}
	
	@Test
	public void testFindName() {
		String name = "Java";
		System.out.println("JJJJJJ" + ProductsStub.getProduct(1L));
		Mockito.when(productRepository.findByName(name)).thenReturn(ProductsStub.getProduct(1L));
		Product product = productService.findByName(name);
		Assert.assertEquals(name, product.getName());
	}
	
	@Test
	public void testFindCategory() throws ShoppingCartException {
		String category = "BOOK";
		Mockito.when(productRepository.findByCategory(ProductCategory.BOOK.value)).thenReturn(ProductsStub.getByCategory(category));
		List<Product> products = productService.findByCategory(category);
		Assert.assertEquals(2,products.size());
	}
	
}
